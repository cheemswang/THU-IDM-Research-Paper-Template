# THU-IDM preprint template

An elegant single-column LaTeX template for technical reports and preprints,
in the spirit of the modern industry-lab preprint layout: a rounded cover panel
that holds the title, authors, affiliations, abstract and lab logo, followed by
a clean serif body with sans-serif headings.

The accent colour is **Tsinghua purple `#660874`**, and the lab mark is placed
in the bottom-right corner of the cover panel.

---

## 1. What is in the package

```
thu-idm-template/
├── thuidm.sty              the style package (this is the template)
├── main.tex                example short paper -- start from this
├── main.pdf                the compiled example
├── example-darkcover.pdf   the same paper with the [darkcover] option
├── refs.bib                example bibliography
├── README.md               this file
└── figures/
    ├── thu-idm-logo-h-purple.png   horizontal lockup, purple   (default)
    ├── thu-idm-logo-h-white.png    horizontal lockup, white    (darkcover default)
    ├── thu-idm-logo-h.png          horizontal lockup, black
    ├── thu-idm-logo-purple.png     stacked logo, purple
    ├── thu-idm-logo-white.png      stacked logo, white
    ├── thu-idm-logo.png            stacked logo, black
    ├── thu-idm-mark*.png           brain mark only (no wordmark)
    ├── example-results.pdf         example figure
    └── example-weights.pdf         example figure
```

All logo files have a **transparent background**, so they sit cleanly on the
light panel, on the dark panel, or on white paper.

---

## 2. Quick start

### Overleaf

1. Zip the folder (or upload it as-is) via **New Project → Upload Project**.
2. Set `main.tex` as the main document.
3. Set the compiler to **pdfLaTeX** (Menu → Compiler). That is the default.
4. Hit Recompile.

### Locally

```bash
latexmk -pdf main.tex
```

or, without `latexmk`:

```bash
pdflatex main
bibtex  main
pdflatex main
pdflatex main
```

The template compiles with a plain TeX Live installation; no manual package
installation is required.

---

## 3. Writing your paper

Open `main.tex`. The cover panel is driven by six commands in the preamble:

```latex
\title{Your Title\\Possibly on Two Lines}

\author{Jiaming Li\aff{1}, Xinyu Chen\aff{1,2}, Qiang Wang\aff{1}}

\affiliation{\aff{1}Institute for Decision Making (THU-IDM), Tsinghua University,\quad
             \aff{2}Shanghai AI Laboratory}

\datestamp{October 9, 2026}

\correspondence{Jiaming Li at \href{mailto:lijm@mails.tsinghua.edu.cn}{lijm@mails.tsinghua.edu.cn}}

\labwebsite[www.thuidm.com]{https://www.thuidm.com/}  % shown text, then link target

\lablogo[10.5mm]{figures/thu-idm-logo-h-purple.png}   % optional: file and height
```

`\aff{...}` typesets the superscript affiliation markers. `\labwebsite` prints
the lab URL in small type directly under the logo, aligned with the bottom of the
metadata block; it defaults to `www.thuidm.com`. Pass only the URL
(`\labwebsite{https://www.thuidm.com/}`) to print it in full, or
`\renewcommand{\thuidm@weburl}{}` inside `\makeatletter ... \makeatother` to
drop the line.

> **Important.** The abstract is typeset *inside* the cover panel, so it must
> appear **before** `\maketitle`:
>
> ```latex
> \begin{document}
> \begin{abstract}
>   ...
> \end{abstract}
> \maketitle
>
> \section{Introduction}
> ```

Everything after that is ordinary `article` LaTeX.

---

## 4. Package options

```latex
\usepackage[option,...]{thuidm}
```

| Option | Effect |
| --- | --- |
| *(none)* | Light Tsinghua-purple cover panel with a purple edge bar — the default. |
| `darkcover` | Deep `#660874` panel with light text; the logo switches to the white version automatically. See `example-darkcover.pdf`. |
| `nocover` | No panel: a plain title block separated by purple rules. |
| `nologo` | Hide the logo on the cover. |
| `blacklinks` | All links in black, for printing or for camera-ready submission. |
| `accent=<hex>` | Change the identity colour, e.g. `accent=1A3C6E`. Six hex digits, no `#`. |

Example: `\usepackage[darkcover,blacklinks]{thuidm}`

---

## 5. Elements provided by the style

### Callout boxes

```latex
\begin{keyfinding}{Summary of findings}
  Replaying intermediate-entropy trajectories recovers the return of tuned
  prioritized replay with $2.6$--$3.2\times$ fewer interactions.
\end{keyfinding}

\begin{sidenote}
  \textbf{Reproducibility.} Configs and seeds are released at \url{...}.
\end{sidenote}
```

`keyfinding` is a tinted box with a purple edge bar and a bold title;
`sidenote` is a light outlined remark. Both break across pages.

### Theorem environments

`theorem`, `lemma`, `proposition`, `corollary` (italic body) and
`definition`, `remark`, `assumption` (upright body) are predefined with purple
sans-serif headers and a shared counter.

### Other helpers

| Command | Effect |
| --- | --- |
| `\aff{1,2}` | Superscript affiliation marker. |
| `\labwebsite[text]{url}` | Lab website under the cover logo. |
| `\thurule` | A thin purple hairline across the text width. |
| `\unnumberedsection{Name}` | Unnumbered section that still appears in the PDF bookmarks. |

### Colours you can use anywhere

`thupurple` (identity `#660874`), `thupurpledark` (headings),
`thupurplemid` (links), `thupurplesoft` (hairlines), `thupanel` (cover fill),
`thutint` (callout fill), `thuink` (body text), `thugray` (secondary text),
and, for dark covers, `thupaper` and `thulilac`.

```latex
\textcolor{thupurple}{highlighted}
```

### Already loaded for you

`amsmath`, `amssymb`, `amsthm`, `bm`, `graphicx`, `xcolor`, `tcolorbox`,
`booktabs`, `enumitem`, `caption`, `subcaption`, `microtype`, `hyperref`,
`cleveref`, and `natbib` (author–year, round brackets). You do **not** need to
load these again. The example additionally loads `algorithm`, `algpseudocode`
and `tabularx`, which you may drop if unused.

Cross-reference with `cleveref` for consistent labels:
`\cref{eq:score}` → "Eq. (1)", `\cref{fig:results}` → "Fig. 2",
`\Cref{tab:main}` at the start of a sentence → "Table 1".

---

## 6. Fonts

The style picks the best available fonts and degrades gracefully, so the same
file compiles on a minimal TeX Live and on Overleaf:

| Role | Preferred | Fallback |
| --- | --- | --- |
| Body serif | `newtxtext` (Times) | `mathptmx` (Times) |
| Math | `newtxmath` (Times math) | `mathptmx` |
| Headings / title sans | `Lato` | TeX Gyre Heros / Helvetica |
| Monospace | `Inconsolata` | Latin Modern Typewriter |

On Overleaf all of the preferred families are present, so your output will look
slightly crisper than `main.pdf` in this package, which was built on a minimal
TeX Live. No change to your source is needed.

### Switching to ICLR-style Computer Modern math

The ICLR (and NeurIPS) template is `\documentclass{article}` plus
`\usepackage{iclr20xx_conference,times}`. `times.sty` resets only the roman,
sans and typewriter families -- it never touches the math fonts -- so those
papers pair Times text with **Computer Modern math**. This template uses Times
math instead, which keeps formulae in the same colour and weight as the
surrounding prose.

To get the ICLR pairing, edit the font block (section 4) of `thuidm.sty` so the
math packages are not loaded:

```latex
\IfFileExists{newtxtext.sty}{\RequirePackage{newtxtext}}%
                            {\renewcommand{\rmdefault}{ptm}}
```

`type1cm` is already loaded for exactly this case: it lets Computer Modern scale
to the non-integer sizes used in the abstract and captions, so the log stays
free of "font shape ... not available" warnings.

### Bold vectors and matrices

`bm` is preloaded, and the example paper follows the usual ICLR convention:
**every vector and matrix is set with `\bm{...}`**, scalars and indices are left
plain.

```latex
\bm{a}         % joint action vector
\bm{\theta}    % parameter vector -- \bm also bolds Greek, \mathbf does not
\bm{\Psi}      % design matrix
\bm{I}_k       % identity
\bm{w}^{\!\top}\bm{\psi}(\xi)
```

Prefer `\bm` over `\mathbf` and `\boldsymbol`: `\mathbf` only reaches upright
Latin letters, so `\mathbf{\theta}` silently does nothing, while `\boldsymbol`
depends on a bold companion being present in the math font and quietly gives up
when it is not. `\bm` handles Latin, Greek and operators alike, and keeps
working if you switch the math font. In subscripts write `\pi_{\bm{\theta}}`
with the braces, not `\pi_\bm{\theta}`.

Equation (2) of the example (label `eq:ridge`) is a worked display that mixes
bold matrices and vectors with plain scalars.

---

## 7. Swapping the logo

Point `\lablogo` at any transparent PNG or PDF:

```latex
\lablogo[12mm]{figures/thu-idm-logo-h-white.png}   % height, then file
```

Use the `-h-` (horizontal) files on the cover — they balance the two metadata
lines on the left, and the website line sits under them. The stacked and mark-only files are there for slides,
posters and letterheads.

If the file is missing, the cover falls back to the words "THU-IDM" in purple
rather than failing to compile.

---

## 8. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| The abstract is missing from the panel | `\begin{abstract}` must come **before** `\maketitle`. |
| `Undefined control sequence \BODY` | Something inside `abstract` broke the capture; avoid `verbatim` there. |
| Citations show as `[?]` | Run `bibtex main`, then `pdflatex` twice (or use `latexmk -pdf`). |
| Logo missing | Check the path in `\lablogo`; paths are relative to `main.tex`. |
| Title too long for two lines | Break it manually with `\\`, or reduce `18.5` in the `\maketitle` font size inside `thuidm.sty`. |

---

*Template v1.0 — 9 October 2026.*
